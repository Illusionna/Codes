## 文件说明

IterationClusterExcel 文件夹放置 python 聚类的 txt 结果，格式不能动.

PermutationResults 文件夹用于存放执行 main 文件夹里代码生成的结果.

testData.xlsx 是转置的测试数据，格式不能动.

main 文件夹里提供两个主文件：main.m 和 main.py.

------

------

------

## 执行步骤

Step1：先将 Iteration???_GMM_Cluster_Result.txt 放到 IterationClusterExcel 文件夹里.

Step2：再执行 main.m 脚本，其中 clusterResultPath = "Iteration???_GMM_Cluster_Result.txt"，选择 testData.xlsx 数据第四列 sample3，ORIGINCOLUMN = 3，生成结果自动保存至 PermutationResults 文件夹.

Step3：最后执行 main.py 代码，路径 io = "../PermutationResults/permutationResult???.xlsx"，即可得到最终排布结果.

