function saveFile(clusterResultPath, Matrix)
    str = clusterResultPath;
    str = char(str);
    serialNumber = str2num(str(isstrprop(char(str), "digit")));
    resultRootPath = "../PermutationResults/";
    resultPath = resultRootPath + "permutationResult" + serialNumber + ".xlsx"
    xlswrite(resultPath, Matrix)
end