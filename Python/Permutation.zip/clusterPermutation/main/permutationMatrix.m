function Matrix = permutationMatrix(M, n_cluster, attributeColumn, clusterSort, ORIGINCOLUMN)
    clusterVectorList = [];
    Matrix = cell(n_cluster,81);
    vector = {};
    resetPos = 0;
    pos = 1;
    for i = 1:1:size(clusterSort,1)
        temp = clusterSort{i};
        index = find(strcmp(attributeColumn, temp));
        if isempty(index)
            resetPos = resetPos + 1;
            if resetPos == 2
                vectorLength = length(vector);
                Matrix(pos,[1:1:vectorLength]) = vector;
                clusterVectorLength = vectorLength;
                clusterVectorList = [clusterVectorList, clusterVectorLength];
                vector = {};
                pos = pos + 1;
                resetPos = 0;
            else
                continue
            end
        else
            value = num2str(M{index,ORIGINCOLUMN}, '%16.15f');
            vector = [vector, value];
        end
    end
    clusterVectorLength = length(vector);
    clusterVectorList = [clusterVectorList, clusterVectorLength];
    vectorLength = length(vector);
    Matrix(pos,[1:1:vectorLength]) = vector;
    maxClusterVectorLength = max(clusterVectorList);
    Matrix(:,[(maxClusterVectorLength+1):1:81]) = [];
end