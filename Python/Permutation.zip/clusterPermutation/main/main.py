from computePermutationMatrix import *

io = "../PermutationResults/permutationResult9.xlsx"
print(compute(io))