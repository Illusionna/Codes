function n_cluster = identifyClusterNumbers(clusterSort)
    n = length(clusterSort);
    n_cluster = 0;
    for i = 1:1:n
        if isempty(clusterSort{i})
            n_cluster = n_cluster + 1;
        end
    end
    n_cluster = n_cluster/2 + 1;
end