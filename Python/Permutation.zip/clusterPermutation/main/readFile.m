function clusterSort = readFile(clusterResultPath)
    f = fopen(clusterResultPath);
    J = {};
    while ~feof(f)
        str = fgetl(f);
        if isempty(str)
            key = {''};
            J = [J, key];
        else
            J = [J, str];
        end
    end
    fclose(f);
    J = J';
    JN = length(J);
    J([JN-1:1:JN],:) = [];
    clusterSort = J;
end