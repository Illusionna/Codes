from readFile import *

def compute(io) -> list:
    M = readFile(io)
    df = M[0]
    n_cluster = M[1][0]
    n = M[1][1]
    Matrix = []
    originalMatrix = []
    for i in range(0, n_cluster, 1):
        data = df.iloc[i].values
        originalMatrix.append(data.tolist())
    originalList = originalMatrix[0]
    for i in range(0, n_cluster, 1):
        originalList = originalMatrix[i]
        tempList = []
        for j in range(0, n, 1):
            temp = originalList[j]
            if str(temp) != 'nan':
                tempList.append(temp)
            else:
                pass
        Matrix.append(tempList)
    return Matrix