import os
import pandas as pd

def cls() -> None:
    os.system("cls")
cls()

def readFile(io) -> None:
    df = pd.read_excel(
        io = io,
        header = None
    )
    L = [df.shape[0], df.shape[1]]
    return (df,L)