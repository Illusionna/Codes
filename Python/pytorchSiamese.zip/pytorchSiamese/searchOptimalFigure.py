import os
import time
import shutil
import warnings
from predict import *

# # ************************************
# 是否迭代遍历整个查询集.
isIteration = False
# 支持集图像路径.
datasetsPath = r".\datasets\images_background"
# 查询集图像路径.
queryFiguresPath = r".\img"
# 最小相似度阈值，范围 [0,1].
minimumSimilarityThresholdValue = 0.25
# 创建 newSpecies 文件夹用于保存“新物种”图片，可修改.
newSpecies = r"./newSpecies"
# # ************************************

def cls(times:int=0) -> None:
    warnings.filterwarnings("ignore")
    time.sleep(times)
    os.system("cls")
cls()

def findMaxIndex(matrix) -> list:
    value = max(map(max, matrix))
    print("\nMaximum Similarity Probability:", value)
    row = len(matrix)
    for i in range(0, row, 1):
        vector = matrix[i]
        column = len(vector)
        for j in range(0, column, 1):
            if vector[j] == value:
                return [(i,j), value]
            else:
                pass

def allNumber() -> int:
    number = 0
    for i in range(0, images_background_length, 1):
        species = images_background_list[i]
        speciesPath = datasetsPath + "\\" + species
        species_list = os.listdir(speciesPath)
        species_length = len(species_list)
        for j in range(0, species_length, 1):
            number = number + 1
    return number

# 默认查询集图片为 .\img\E.pngE.png.
def computeProbabilityMatrix(queryFigurePath:str=r".\img\E.png") -> None:
    all = allNumber()
    pos = 1
    for i in range(0, images_background_length, 1):
        tempList = []
        species = images_background_list[i]
        speciesPath = datasetsPath + "\\" + species
        species_list = os.listdir(speciesPath)
        species_length = len(species_list)
        Species_Dictionary[i] = speciesPath
        for j in range(0, species_length, 1):
            creature = species_list[j]
            creature_path = speciesPath + "\\" + creature
            model = Siamese()
            image_1 = queryFigurePath
            image_2 = creature_path
            image_1 = Image.open(image_1)
            image_2 = Image.open(image_2)
            probability = model.detect_image(image_1,image_2)
            tempList.append(round(probability.item(),4))
            Index_relativePath_Dictionary[(i,j)] = creature_path
            print(probability)
            print(f"Iteration: {pos} / {all}", "\n")
            pos = pos + 1
        probabilityMatrix.append(tempList)

def isMovePictureToFolder(judge:bool=False, From:str="", To:str="", show:bool=True) -> None:
    if judge == False:
        pass
    elif judge == True:
        shutil.copy(From, To)
        string = os.path.basename(From)
        if show == True:
            # 打印“图片已被拷贝到文件夹 XXX 下”.
            print("")
            print(f"""The picture has been copied to the folder "{string}".""", "\n")
        elif show == False:
            pass



if __name__ == "__main__":
    if isIteration == False:
        queryFiguresList = os.listdir(queryFiguresPath)
        # 默认查询集图片为第五张.
        queryFigurePath = queryFiguresPath + "\\" + queryFiguresList[4]
        images_background_list = os.listdir(datasetsPath)
        images_background_length = len(images_background_list)

        probabilityMatrix = []
        Index_relativePath_Dictionary = {}
        Species_Dictionary = {}

        computeProbabilityMatrix()
        print(probabilityMatrix)

        index = findMaxIndex(probabilityMatrix)
        optimalFigurePath = Index_relativePath_Dictionary[index[0]]
        print(optimalFigurePath, "\n")

        model = Siamese()
        queryFigure = Image.open(queryFigurePath)
        optimalFigure = Image.open(optimalFigurePath)
        # 默认显示绘制图像.
        probability = model.detect_image(queryFigure, optimalFigure, True)

        if probability <= minimumSimilarityThresholdValue:
            print("")
            print(f"""Similarity:{index[1]}. This is a new species that has been copied to filesfolder "newSpecies".""", "\n")
            os.makedirs(newSpecies, exist_ok=True)
            # 默认为把查询图片拷贝至新物种文件夹，并且不显示打印内容.
            isMovePictureToFolder(True, queryFigurePath, newSpecies, False)
        else:
            originalSpeciesPath = Species_Dictionary[index[0][0]]
            similarSpecies = os.path.basename(originalSpeciesPath)
            print("")
            print(f"""Similarity:{index[1]}. This picture is most similar to "{similarSpecies}".""", "\n")
            # 默认不把查询图片拷贝至相应的支持集文件夹中，若拷贝则显示打印内容.
            isMovePictureToFolder(False, queryFigurePath, originalSpeciesPath, show=True)

    elif isIteration == True:
        queryFiguresList = os.listdir(queryFiguresPath)
        n = len(queryFiguresList)
        pos = 1
        for t in range(0, n, 1):
            queryFigurePath = queryFiguresPath + "\\" + queryFiguresList[t]
            print(f"第 {pos} 轮:", queryFigurePath)
            pos = pos + 1

            images_background_list = os.listdir(datasetsPath)
            images_background_length = len(images_background_list)

            probabilityMatrix = []
            Index_relativePath_Dictionary = {}
            Species_Dictionary = {}

            computeProbabilityMatrix(queryFigurePath)
            print(probabilityMatrix, "\n\n")

            index = findMaxIndex(probabilityMatrix)
            optimalFigurePath = Index_relativePath_Dictionary[index[0]]
            print(optimalFigurePath, "\n")

            model = Siamese()
            queryFigure = Image.open(queryFigurePath)
            optimalFigure = Image.open(optimalFigurePath)
            # 默认不显示绘制图像.
            probability = model.detect_image(queryFigure, optimalFigure, False)

            if probability <= minimumSimilarityThresholdValue:
                print("")
                print(f"""Similarity:{index[1]}. This is a new species that has been copied to filesfolder "newSpecies".""", "\n")
                os.makedirs(newSpecies, exist_ok=True)
                # 默认为把查询图片拷贝至新物种文件夹，并且不显示打印内容.
                isMovePictureToFolder(True, queryFigurePath, newSpecies, False)
            else:
                originalSpeciesPath = Species_Dictionary[index[0][0]]
                similarSpecies = os.path.basename(originalSpeciesPath)
                print("")
                print(f"""Similarity:{index[1]}. This picture is most similar to "{similarSpecies}".""", "\n")
                # 默认不把查询图片拷贝至相应的支持集文件夹中，若拷贝则显示打印内容.
                isMovePictureToFolder(False, queryFigurePath, originalSpeciesPath, show=True)