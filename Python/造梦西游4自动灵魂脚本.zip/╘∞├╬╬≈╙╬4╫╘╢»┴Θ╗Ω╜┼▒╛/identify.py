'''
# System --> Windows & Python3.8.0
# File ----> identify.py
# Author --> Illusionna
# Create --> 2024/01/26 20:40:19
'''
# -*- Encoding: UTF-8 -*-


import re
import time
import ddddocr
import pyautogui
from PIL import Image


class OCR:
    def __init__(self) -> None:
        self.ocr = ddddocr.DdddOcr()

    def Capture() -> Image:
        x = 1017
        y = 750
        width = 175
        height = 33
        capture = pyautogui.screenshot(
            region = (
                x,
                y,
                width,
                height
            )
        )
        return capture

    def DifferenceMoney(self) -> int:
        pyautogui.moveTo(541, 173, duration=0.2)
        pyautogui.click()
        time.sleep(2)
        text = self.ocr.classification(OCR.Capture())
        numbers = re.findall(r'\d+', text)
        startMoney = [int(n) for n in numbers]
        pyautogui.moveTo(1404, 186, duration=0.2)
        pyautogui.click()
        time.sleep(2)
        return startMoney