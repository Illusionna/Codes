import os
import time
import random
import numpy as np
import pyttsx3 as pt
from PIL import Image
import pyautogui as gcf
from identify import OCR
from skimage.metrics import structural_similarity as Similarity

def cls() -> None:
    os.system('cls')
    gcf.FAILSAFE = False
cls()

def Capture() -> Image:
    x = 755
    y = 765
    width = 80
    height = 80
    capture = gcf.screenshot(
        region = (
            x,
            y,
            width,
            height
        )
    )
    return capture

def MapScreen() -> bool:
    capture = np.array(Capture().convert('L').resize((80, 80)))
    mission = np.array(Image.open('./GameCaptureImages/mission.png').convert('L').resize((80, 80)))
    similarity = Similarity(capture, mission)
    print(f'\033[3{random.randint(1, 8)}m地图相似度: {similarity}\033[0m')
    if similarity >= 0.95:
        return True
    else:
        return False

def LoadingScreen() ->bool:
    capture = np.array(Capture().convert('L').resize((80, 80)))
    mission = np.array(Image.open('./GameCaptureImages/loading.png').convert('L').resize((80, 80)))
    similarity = Similarity(capture, mission)
    print(f'\033[3{random.randint(1, 8)}m加载相似度: {similarity}\033[0m')
    if similarity >= 0.95:
        return True
    else:
        return False

def GameScreen() -> bool:
    capture = np.array(Capture().convert('L').resize((80, 80)))
    mission = np.array(Image.open('./GameCaptureImages/gaming.png').convert('L').resize((80, 80)))
    similarity = Similarity(capture, mission)
    print(f'\033[3{random.randint(1, 8)}m游戏界面相似度: {similarity}\033[0m')
    if similarity >= 0.95:
        return True
    else:
        return False

def WhiteScreen() -> bool:
    capture = np.array(Capture().convert('L').resize((80, 80)))
    mission = np.array(Image.open('./GameCaptureImages/white.png').convert('L').resize((80, 80)))
    similarity = Similarity(capture, mission)
    print(f'\033[3{random.randint(1, 8)}m白屏相似度: {similarity}\033[0m')
    if similarity >= 0.95:
        return True
    else:
        return False

def Speech() -> None:
    for i in range(0, 3, 1):
        engine = pt.init()
        engine.setProperty('rate', 175)
        engine.setProperty('volume',1)
        pt.speak('Warning')
        engine.setProperty('rate', 125)
        engine.setProperty('volume',0.75)
        pt.speak('Error')
        pt.speak('Error')

def AcceptMission() -> None:
    gcf.moveTo(793, 802, duration=0.2)
    gcf.click()
    gcf.moveTo(746, 276, duration=0.2)
    gcf.click()
    gcf.moveTo(1031, 746, duration=0.2)
    gcf.click()

def Attack() -> None:
    gcf.press('C')
    time.sleep(0.1)
    gcf.press('C')
    time.sleep(0.1)
    gcf.press('L')

def BackToMap() -> None:
    gcf.moveTo(1098, 816, duration=0.2)
    gcf.click()
    time.sleep(0.25)
    gcf.moveTo(963, 415, duration=0.25)
    gcf.click()

def Flush() -> None:
    gcf.moveTo(1223, 874, duration=0.2)
    gcf.click()
    gcf.moveTo(417, 926, duration=0.2)
    gcf.click()
    time.sleep(25)
    gcf.moveTo(957, 771, duration=0.2)
    gcf.click()
    time.sleep(4)
    gcf.moveTo(1115, 632, duration=0.2)
    gcf.click()
    time.sleep(3)
    gcf.moveTo(410, 874, duration=0.2)
    gcf.click()
    gcf.moveTo(576, 937, duration=0.2)
    gcf.click()
    time.sleep(3)

def Operation() -> None:
    if MapScreen() == True:
        time.sleep(0.5)
        AcceptMission()
        time.sleep(2)
        if GameScreen() == True:
            Attack()
            time.sleep(3.5)
            BackToMap()
            time.sleep(1)
            if MapScreen() == True:
                pass
            else:
                time.sleep(3)
                if MapScreen() == True:
                    pass
                else:
                    Speech()
                    Flush()
        elif LoadingScreen() == True:
            time.sleep(5)
            if GameScreen() == True:
                Attack()
                time.sleep(3.5)
                BackToMap()
                time.sleep(1)
                if MapScreen() == True:
                    pass
                else:
                    time.sleep(3)
                    if MapScreen() == True:
                        pass
                    else:
                        Speech()
                        Flush()
            else:
                Speech()
                Flush()
        elif WhiteScreen() == True:
            Speech()
            Flush()
        else:
            Speech()
            Flush()
    else:
        Speech()
        Flush()

def Iteration(epoch:int=3) -> None:
    stamp = time.time()
    for n in range(0, epoch, 1):
        print(f'Iteration: {n+1}/{epoch}')
        print('------------------------')
        Operation()
        now = time.strftime("%H:%M:%S", time.gmtime(time.time()-stamp))
        print('------------------------')
        print(f'time ==>> {now}\n')


if __name__ == '__main__':
    judge = input('Are you ready?\n')
    if judge.lower() == 'y':
        epoch = eval(input('Epoch = '))
        time.sleep(3)
        cls()
        print('<<========Starting========>>\n\n')
        obj = OCR()
        startMoney = obj.DifferenceMoney()
        Iteration(epoch)
        endMoney = obj.DifferenceMoney()
        print(f'\033[33m迭代前灵魂: {startMoney}\033[0m')
        print(f'\033[33m迭代后灵魂: {endMoney}\033[0m')
        print(f'\033[33m灵魂增益量: {endMoney[0]-startMoney[0]}\033[0m')
        print('\n<<========Executed========>>\n')