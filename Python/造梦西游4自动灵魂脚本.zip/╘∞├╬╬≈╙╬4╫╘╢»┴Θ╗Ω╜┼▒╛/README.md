## 简介

造梦西游 Ⅳ 北俱芦洲悟空自动刷大盗**获取灵魂脚本**.

## 环境

- ```python
  pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pyttsx3
  ```

- ```python
  pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pyautogui
  ```


## 使用

1. 关闭防火墙，解压“造Ⅳ修改器.zip”， 打开修改器选择“火魔斩”一键修改秒杀.
2. 运行 GameScript.py 脚本.

## 注意

电脑分辨率：1920x1080，不要拖动造梦西游修改器初始窗口位置，进入北俱芦洲地图界面.

## 结果

![](./stream/1000轮.png)

## 示范

#### 正常使用

<video src="./stream/normal.mp4">

#### 异常排除

<video src="./stream/abnormal.mp4">