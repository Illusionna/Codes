clear
clc

disp("<<------------------Starting------------------>>")

ORIGINCOLUMN = 3    % The default is the third column "sample3".
dataPath = "../testData.xlsx"
clusterResultPath = "Iteration12_GMM_Cluster_Result.txt";
clusterResultPath = "../IterationClusterExcel/" + clusterResultPath

[pureData, M] = xlsread(dataPath);
clusterSort = readFile(clusterResultPath);

row = size(M,1);
column = size(M,2);

M = fillDataElement(row, column, pureData, M);
n_cluster = identifyClusterNumbers(clusterSort)
attributeColumn = returnAttributeColumn(row, M);

Matrix = permutationMatrix(...
    M ,...
    n_cluster ,...
    attributeColumn ,...
    clusterSort ,...
    ORIGINCOLUMN+1 ...
);

saveFile(clusterResultPath, Matrix)

disp("<<------------------Executed------------------>>")