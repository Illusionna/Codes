function M = fillDataElement(row, column, pureData, M)
    for i = 2:1:row
        temp = num2cell(pureData(i-1,:));
        M(i,[2:1:column]) = temp;
    end
end