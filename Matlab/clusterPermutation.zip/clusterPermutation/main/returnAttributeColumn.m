function attributeColumn = returnAttributeColumn(row, M)
    J = {' '};
    for i = 2:1:row
        J = [J, M{i,1}];
    end
    J = J';
    attributeColumn = J;
end